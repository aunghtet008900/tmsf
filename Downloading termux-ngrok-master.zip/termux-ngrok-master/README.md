# termux-ngrok
O [ngrok](https://ngrok.com/) é um serviço que disponibiliza servidores por trás de redes NATs e Firewalls que realizam conexão publicas em túneis [documentação](https://ngrok.com/docs).

### Instalando ngrok no Termux
```
apt update && apt upgrade
apt install git
git clone https://github.com/tchelospy/termux-ngrok.git
cd termux-ngrok
chmod +x termux-ngrok.sh
./termux-ngrok.sh
```
### Screenshot

<p align="centre">
<img src="https://i.imgur.com/86lzmIf.png" alt="Script">
</p>

<p align="centre">
<img src="https://i.imgur.com/sRb2y4P.png" alt="Script">
</p>

<p align="centre">
<img src="https://i.imgur.com/m80I9UB.png" alt="Script">
</p>



