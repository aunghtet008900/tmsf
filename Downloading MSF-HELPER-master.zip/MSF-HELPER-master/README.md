# MSF-HELPER
```
Metasploit Helper, can helping you for :
- Installing Metasploit
- Installing Ngrok
- Creating Any Backdoor Msfvenom
- Just Type and Enter
```
# INSTALLATION
```
$ pkg update && pkg upgrade
$ pkg install git
$ git clone https://github.com/pengangguranmuda/MSF-HELPER
$ cd MSF-HELPER
$ chmod +x *
$ sh install.sh
$ ./setup.sh
```





